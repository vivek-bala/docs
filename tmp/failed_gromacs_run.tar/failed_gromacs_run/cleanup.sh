rm ener.edr md.log mdout.mdp topol.tpr \#* gromacs-bpti* confout.gro state* md.cpt  md.edr  md.gro  md.tpr  md.xtc -rf
